package classloading;
public class User {

	public String getName() {
		return "Bharath";
	}

	public String getEmail() {
		return "bharath@gmail.com";
	}

}
