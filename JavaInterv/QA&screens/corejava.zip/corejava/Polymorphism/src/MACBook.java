public class MACBook implements AppleLaptop{

	public void start() {
		System.out.println("Inside MacBooks start()");
	}

	public void shutdown() {
		System.out.println("Inside MacBooks shutdown()");
	}
}
