
public interface AppleLaptop {

	void start();
	void shutdown();
}
