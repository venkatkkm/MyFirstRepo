package interfaces;

public class Test {

	public static void main(String[] args) {
		Honda h = new Honda();
		h.go();
		h.stop();
	}
}
