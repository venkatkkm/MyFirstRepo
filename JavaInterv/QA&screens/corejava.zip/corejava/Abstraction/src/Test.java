
public class Test {

	public static void main(String[] args) {
		ThreeSeries threeSeries = new ThreeSeries();
		threeSeries.accelerate();
		threeSeries.commonFunc();
		
		FiveSeries fiveSeries = new FiveSeries();
		fiveSeries.accelerate();
		fiveSeries.commonFunc();
		
	}
}
