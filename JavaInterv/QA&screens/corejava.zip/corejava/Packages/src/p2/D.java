package p2;

public class D {

	public static void main(String[] args) {
		A.a1();
		p1.A.a1();
	}

}
