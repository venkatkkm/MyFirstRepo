package p2;

public class A {

	public static void a1() {
		System.out.println("Inside p2.As a1 method");
	}
}
