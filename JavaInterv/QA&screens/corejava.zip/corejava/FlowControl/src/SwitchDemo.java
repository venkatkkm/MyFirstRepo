public class SwitchDemo {

	public static void main(String[] args) {

		int x = 2;

		switch (x) {

		case 1:
		case 2:
			System.out.println("Common Logic");
			break;
		default:
			System.out.println("Default");
		}

	}

}
