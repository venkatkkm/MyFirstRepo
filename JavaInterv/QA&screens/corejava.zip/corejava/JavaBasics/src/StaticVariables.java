public class StaticVariables {

	static int num;

	public static void main(String[] args) {
		System.out.println(StaticVariables.num);
	}
}
