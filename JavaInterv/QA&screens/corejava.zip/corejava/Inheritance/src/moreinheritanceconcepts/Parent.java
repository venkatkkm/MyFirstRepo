package moreinheritanceconcepts;

public class Parent {
	
	int a,b;
	
	Parent(int a,int b){
		this.a = a;
		this.b = b;
	}

	void f1(){
		System.out.println("Inside parents f1()");
	}
}
