package moreinheritanceconcepts;

public class NonFinalClass extends FinalClass{
	
	public static void main(String[] args) {
		float f = FinalClass.pi ;
		System.out.println(FinalClass.pi);
	}

}
