
public class Parent{
	
	Parent(){
		System.out.println("Parents Object"+this);
	}
	
	void f1(){
		System.out.println("Inside Parents f1");
	}

}
