
public class Bike extends Vehicle{

}
