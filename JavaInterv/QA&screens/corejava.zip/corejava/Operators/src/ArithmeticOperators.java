public class ArithmeticOperators {

	public static void main(String[] args) {

		int x = 20, y = 3;

		System.out.println("Addition:" + (x + y));
		System.out.println("Subtraction:" + (x - y));
		System.out.println("Multiplication:" + (x * y));
		System.out.println("Division:" + (x / y));
		System.out.println("Reminder:" + (x % y));

	}

}
