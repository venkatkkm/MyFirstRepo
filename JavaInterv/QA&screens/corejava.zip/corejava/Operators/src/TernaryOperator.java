
public class TernaryOperator {

	public static void main(String[] args) {
		
		int x = 40,y=30;
		
		String result = (x>y)?"x is greater":"y is greater";
		
		System.out.println(result);

	}

}
