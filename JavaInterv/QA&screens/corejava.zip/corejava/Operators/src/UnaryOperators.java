public class UnaryOperators {

	public static void main(String[] args) {

		int x = 10;
		int y = x--;

		System.out.println("Value of x:" + x);
		System.out.println("Value of y:" + y);

	}

}
