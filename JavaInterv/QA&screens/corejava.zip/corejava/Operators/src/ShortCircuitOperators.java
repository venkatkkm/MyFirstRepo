public class ShortCircuitOperators {

	public static void main(String[] args) {

		boolean x = true, y = false;

		if (x || y) {
			System.out.println("Inside If");
		}

	}

}
