public class Test {

	public static void main(String[] args) {

		Product product = new Product(1, "Iphone");

		System.out.println(product);

		String s = "123";

		Integer i = new Integer(456);

		System.out.println(s);
		System.out.println(i);

	}

}
