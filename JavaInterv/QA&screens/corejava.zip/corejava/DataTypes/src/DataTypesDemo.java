
public class DataTypesDemo {

	public static void main(String[] args) {
		
		byte a = -50;
		short b = 150;
		int c = 10000;
		long d = 100000;
		char e='A';
		
		float f= 1.23f;
		double g = 12345.6789;
		
		byte h =20;
		
		byte result = (byte) (a+h);

	}

}
