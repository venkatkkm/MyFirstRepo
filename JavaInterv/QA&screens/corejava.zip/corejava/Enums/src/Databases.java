
public enum Databases{
	MYSQL,ORACLE,SQLSERVER;
}
