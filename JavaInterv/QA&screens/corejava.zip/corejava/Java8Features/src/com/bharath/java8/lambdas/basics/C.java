package com.bharath.java8.lambdas.basics;

public class C implements A {

	@Override
	public void myMethod() {
		System.out.println("Inside MyMethod");
	}

}
