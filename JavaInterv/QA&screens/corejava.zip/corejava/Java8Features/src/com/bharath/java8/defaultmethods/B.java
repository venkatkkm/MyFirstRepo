package com.bharath.java8.defaultmethods;

public class B implements A,X {

	public void m1(){
		System.out.println("M1 inside B");
	}
}
